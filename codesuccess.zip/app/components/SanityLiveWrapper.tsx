import { SanityLive } from "@/sanity/lib/live";

export default function SanityLiveWrapper() {
  return <SanityLive />;
}
